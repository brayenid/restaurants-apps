import { openDB } from 'idb'
import Base from './base-data'

const { DATABASE_NAME, DATABASE_VERSION, OBJECT_STORE_NAME } = Base

const dbPromise = openDB(DATABASE_NAME, DATABASE_VERSION, {
  upgrade(database) {
    database.createObjectStore(OBJECT_STORE_NAME, { keyPath: 'id' })
  }
})

const FavoriteResto = {
  async getResto(id) {
    return (await dbPromise).get(OBJECT_STORE_NAME, id)
  },
  async getAllRestos() {
    return (await dbPromise).getAll(OBJECT_STORE_NAME)
  },
  async addResto(resto) {
    return (await dbPromise).put(OBJECT_STORE_NAME, resto)
  },
  async deleteResto(id) {
    return (await dbPromise).delete(OBJECT_STORE_NAME, id)
  }
}

export default FavoriteResto
