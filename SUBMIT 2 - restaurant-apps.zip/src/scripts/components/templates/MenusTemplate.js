const menusEl = () => {
  return `
    <h2>Menu</h2>
    <div class="foods">
      <h3>Makanan : </h3>
      <ul></ul>
    </div>
    <div class="drinks">
      <h3>Minuman : </h3>
      <ul></ul>
    </div>
    `
}
export default menusEl
